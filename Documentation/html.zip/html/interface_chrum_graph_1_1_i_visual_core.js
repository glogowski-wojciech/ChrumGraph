var interface_chrum_graph_1_1_i_visual_core =
[
    [ "CreateEdge", "interface_chrum_graph_1_1_i_visual_core.html#a7aaa598ee4e05c3090e8c022567b6bda", null ],
    [ "CreateVertex", "interface_chrum_graph_1_1_i_visual_core.html#a81012660366494fe6121d3a4583c6b96", null ],
    [ "LoadFromFile", "interface_chrum_graph_1_1_i_visual_core.html#ae3504bb63bab29a1a18bfca549988c37", null ],
    [ "Pin", "interface_chrum_graph_1_1_i_visual_core.html#a6cd770b9130acb64357bb1fe616981b0", null ],
    [ "RemoveEdge", "interface_chrum_graph_1_1_i_visual_core.html#a63cd8796eadadbd7e8c02b79e711aaee", null ],
    [ "RemoveVertex", "interface_chrum_graph_1_1_i_visual_core.html#a513a2a7231d708dda1c7b381d492078f", null ],
    [ "SaveGraph", "interface_chrum_graph_1_1_i_visual_core.html#a74a319a9bfc4de606512893d06de920c", null ],
    [ "SaveVisualGraph", "interface_chrum_graph_1_1_i_visual_core.html#a888f035664bd553cf10dbe8ab954f34b", null ],
    [ "SetPosition", "interface_chrum_graph_1_1_i_visual_core.html#a7beca25a39503639d0f68b44a264cbe5", null ],
    [ "Unpin", "interface_chrum_graph_1_1_i_visual_core.html#af1c292a43940ded39125c88086cf167a", null ],
    [ "VertexClicked", "interface_chrum_graph_1_1_i_visual_core.html#a4c9081b2d2d9f27b6c7e7dceafff7cb8", null ],
    [ "VertexUnclicked", "interface_chrum_graph_1_1_i_visual_core.html#abef6d01ad4e3e1fcfa719d9f4749d2ae", null ]
];