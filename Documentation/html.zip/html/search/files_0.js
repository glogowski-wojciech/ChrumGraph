var searchData=
[
  ['app_2eg_2ecs',['App.g.cs',['../_app_8g_8cs.html',1,'']]],
  ['app_2eg_2ei_2ecs',['App.g.i.cs',['../_app_8g_8i_8cs.html',1,'']]],
  ['app_2examl_2ecs',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
