var searchData=
[
  ['unpin',['Unpin',['../class_chrum_graph_1_1_core.html#a64aa923056d0d3d19f1956a31dfae919',1,'ChrumGraph.Core.Unpin()'],['../interface_chrum_graph_1_1_i_visual_core.html#af1c292a43940ded39125c88086cf167a',1,'ChrumGraph.IVisualCore.Unpin()']]]
];
