var searchData=
[
  ['loadfromfile',['LoadFromFile',['../class_chrum_graph_1_1_core.html#acead75352c6d16fc20beae712e3e9fde',1,'ChrumGraph.Core.LoadFromFile()'],['../interface_chrum_graph_1_1_i_visual_core.html#ae3504bb63bab29a1a18bfca549988c37',1,'ChrumGraph.IVisualCore.LoadFromFile()']]]
];
