var searchData=
[
  ['refresh',['Refresh',['../class_chrum_graph_1_1_visual.html#a7045ea0af129d77b44222102c1522d0a',1,'ChrumGraph.Visual.Refresh()'],['../interface_chrum_graph_1_1_i_visual.html#a286209d2bf9ed15a9c27dfa6c1ec4016',1,'ChrumGraph.IVisual.Refresh()']]],
  ['removeedge',['RemoveEdge',['../class_chrum_graph_1_1_core.html#a6fb6b01b2ff70f99c12d70116a83683d',1,'ChrumGraph.Core.RemoveEdge()'],['../interface_chrum_graph_1_1_i_visual_core.html#a63cd8796eadadbd7e8c02b79e711aaee',1,'ChrumGraph.IVisualCore.RemoveEdge()']]],
  ['removevertex',['RemoveVertex',['../class_chrum_graph_1_1_core.html#a4d1dac79bbce9f0a3558fb9d3f20eeb4',1,'ChrumGraph.Core.RemoveVertex()'],['../interface_chrum_graph_1_1_i_visual_core.html#a513a2a7231d708dda1c7b381d492078f',1,'ChrumGraph.IVisualCore.RemoveVertex()']]],
  ['removevisualedge',['RemoveVisualEdge',['../class_chrum_graph_1_1_visual.html#a900487f92337d6ad8f5f2aaf7e28b325',1,'ChrumGraph.Visual.RemoveVisualEdge()'],['../interface_chrum_graph_1_1_i_visual.html#a8336e6c2f8e5601f491bc5beaa5eb3db',1,'ChrumGraph.IVisual.RemoveVisualEdge()']]],
  ['removevisualvertex',['RemoveVisualVertex',['../class_chrum_graph_1_1_visual.html#a88eb99b4425756454c18bb299b709382',1,'ChrumGraph.Visual.RemoveVisualVertex()'],['../interface_chrum_graph_1_1_i_visual.html#a8b822ba5e806e022657f6f49a9e64a1d',1,'ChrumGraph.IVisual.RemoveVisualVertex()']]]
];
