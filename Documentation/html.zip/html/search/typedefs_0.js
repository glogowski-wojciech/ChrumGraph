var searchData=
[
  ['visual',['Visual',['../_main_window_8xaml_8cs.html#aa983acfb49390b94212b65390fc34d2c',1,'MainWindow.xaml.cs']]]
];
