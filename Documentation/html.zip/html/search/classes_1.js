var searchData=
[
  ['core',['Core',['../class_chrum_graph_1_1_core.html',1,'ChrumGraph']]]
];
