var searchData=
[
  ['clicked',['Clicked',['../class_chrum_graph_1_1_vertex.html#a48af0f013d09003aa4a5fdb620470ed1',1,'ChrumGraph::Vertex']]]
];
