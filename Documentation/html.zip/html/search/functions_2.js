var searchData=
[
  ['initializecomponent',['InitializeComponent',['../class_chrum_graph_1_1_app.html#a5ab75b4e546d356bf01d74912db55e4b',1,'ChrumGraph.App.InitializeComponent()'],['../class_chrum_graph_1_1_app.html#a5ab75b4e546d356bf01d74912db55e4b',1,'ChrumGraph.App.InitializeComponent()'],['../class_chrum_graph_1_1_main_window.html#ae891d0c871e874620662e66f68f60f68',1,'ChrumGraph.MainWindow.InitializeComponent()'],['../class_chrum_graph_1_1_main_window.html#ae891d0c871e874620662e66f68f60f68',1,'ChrumGraph.MainWindow.InitializeComponent()']]]
];
