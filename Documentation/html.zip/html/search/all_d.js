var searchData=
[
  ['x',['X',['../class_chrum_graph_1_1_vertex.html#a847e9c9ebb895ed9db8f875e6072921b',1,'ChrumGraph::Vertex']]]
];
