var searchData=
[
  ['main',['Main',['../class_chrum_graph_1_1_app.html#aea1686a9dd8c3a77bc918846c2c6f4a6',1,'ChrumGraph.App.Main()'],['../class_chrum_graph_1_1_app.html#aea1686a9dd8c3a77bc918846c2c6f4a6',1,'ChrumGraph.App.Main()']]],
  ['mainwindow',['MainWindow',['../class_chrum_graph_1_1_main_window.html#a0e61c0b00a466cfec622c7850746dabf',1,'ChrumGraph::MainWindow']]],
  ['mainwindow',['MainWindow',['../class_chrum_graph_1_1_main_window.html',1,'ChrumGraph']]]
];
