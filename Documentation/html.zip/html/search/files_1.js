var searchData=
[
  ['core_2ecs',['Core.cs',['../_core_8cs.html',1,'']]]
];
