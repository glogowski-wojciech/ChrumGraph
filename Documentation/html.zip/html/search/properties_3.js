var searchData=
[
  ['label',['Label',['../class_chrum_graph_1_1_vertex.html#af70810a71ec6e2e089dea2a7d17400e1',1,'ChrumGraph::Vertex']]]
];
