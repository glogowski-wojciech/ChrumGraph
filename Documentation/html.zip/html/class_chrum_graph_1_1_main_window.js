var class_chrum_graph_1_1_main_window =
[
    [ "MainWindow", "class_chrum_graph_1_1_main_window.html#a0e61c0b00a466cfec622c7850746dabf", null ],
    [ "InitializeComponent", "class_chrum_graph_1_1_main_window.html#ae891d0c871e874620662e66f68f60f68", null ],
    [ "InitializeComponent", "class_chrum_graph_1_1_main_window.html#ae891d0c871e874620662e66f68f60f68", null ]
];