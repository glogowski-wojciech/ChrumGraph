var namespaces =
[
    [ "ChrumGraph", "namespace_chrum_graph.html", "namespace_chrum_graph" ]
];