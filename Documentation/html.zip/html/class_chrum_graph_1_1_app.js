var class_chrum_graph_1_1_app =
[
    [ "InitializeComponent", "class_chrum_graph_1_1_app.html#a5ab75b4e546d356bf01d74912db55e4b", null ],
    [ "InitializeComponent", "class_chrum_graph_1_1_app.html#a5ab75b4e546d356bf01d74912db55e4b", null ]
];