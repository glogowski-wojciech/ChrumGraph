var _main_window_8xaml_8cs =
[
    [ "MainWindow", "class_chrum_graph_1_1_main_window.html", "class_chrum_graph_1_1_main_window" ],
    [ "Visual", "_main_window_8xaml_8cs.html#aa983acfb49390b94212b65390fc34d2c", null ]
];