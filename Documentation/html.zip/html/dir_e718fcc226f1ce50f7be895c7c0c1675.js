var dir_e718fcc226f1ce50f7be895c7c0c1675 =
[
    [ "Core.cs", "_core_8cs.html", [
      [ "Core", "class_chrum_graph_1_1_core.html", "class_chrum_graph_1_1_core" ]
    ] ],
    [ "Edge.cs", "_edge_8cs.html", [
      [ "Edge", "class_chrum_graph_1_1_edge.html", "class_chrum_graph_1_1_edge" ]
    ] ],
    [ "Physics.cs", "_physics_8cs.html", [
      [ "Physics", "class_chrum_graph_1_1_physics.html", "class_chrum_graph_1_1_physics" ]
    ] ],
    [ "Vertex.cs", "_vertex_8cs.html", [
      [ "Vertex", "class_chrum_graph_1_1_vertex.html", "class_chrum_graph_1_1_vertex" ]
    ] ],
    [ "Visual.cs", "_visual_8cs.html", [
      [ "Visual", "class_chrum_graph_1_1_visual.html", "class_chrum_graph_1_1_visual" ]
    ] ]
];