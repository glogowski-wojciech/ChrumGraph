var hierarchy =
[
    [ "Application", null, [
      [ "ChrumGraph.App", "class_chrum_graph_1_1_app.html", null ],
      [ "ChrumGraph.App", "class_chrum_graph_1_1_app.html", null ],
      [ "ChrumGraph.App", "class_chrum_graph_1_1_app.html", null ]
    ] ],
    [ "ChrumGraph.Edge", "class_chrum_graph_1_1_edge.html", null ],
    [ "IComponentConnector", null, [
      [ "ChrumGraph.MainWindow", "class_chrum_graph_1_1_main_window.html", null ],
      [ "ChrumGraph.MainWindow", "class_chrum_graph_1_1_main_window.html", null ]
    ] ],
    [ "ChrumGraph.IPhysics", "interface_chrum_graph_1_1_i_physics.html", [
      [ "ChrumGraph.Physics", "class_chrum_graph_1_1_physics.html", null ]
    ] ],
    [ "ChrumGraph.IPhysicsCore", "interface_chrum_graph_1_1_i_physics_core.html", [
      [ "ChrumGraph.Core", "class_chrum_graph_1_1_core.html", null ]
    ] ],
    [ "ChrumGraph.IVisual", "interface_chrum_graph_1_1_i_visual.html", [
      [ "ChrumGraph.Visual", "class_chrum_graph_1_1_visual.html", null ]
    ] ],
    [ "ChrumGraph.IVisualCore", "interface_chrum_graph_1_1_i_visual_core.html", [
      [ "ChrumGraph.Core", "class_chrum_graph_1_1_core.html", null ]
    ] ],
    [ "ChrumGraph.Vertex", "class_chrum_graph_1_1_vertex.html", null ],
    [ "Window", null, [
      [ "ChrumGraph.MainWindow", "class_chrum_graph_1_1_main_window.html", null ],
      [ "ChrumGraph.MainWindow", "class_chrum_graph_1_1_main_window.html", null ],
      [ "ChrumGraph.MainWindow", "class_chrum_graph_1_1_main_window.html", null ]
    ] ]
];