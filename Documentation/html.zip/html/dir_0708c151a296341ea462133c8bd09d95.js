var dir_0708c151a296341ea462133c8bd09d95 =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", null ]
];