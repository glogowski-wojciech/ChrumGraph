var class_chrum_graph_1_1_physics =
[
    [ "Physics", "class_chrum_graph_1_1_physics.html#a71c36572cc4a3ef7dec1da32e3253318", null ],
    [ "StartSimulation", "class_chrum_graph_1_1_physics.html#a9f0121c2d2287423c34ef0ba9c5928b5", null ],
    [ "StartSimulation", "class_chrum_graph_1_1_physics.html#a4dbc58c05729afdb41d9f2f4348ae56e", null ],
    [ "StopSimulation", "class_chrum_graph_1_1_physics.html#a85e50984dee46c18e74589d9bcec197e", null ],
    [ "EdgeForceParam", "class_chrum_graph_1_1_physics.html#a5b1ffa6c66b4bc95a6d357d19939943f", null ],
    [ "FrictionParam", "class_chrum_graph_1_1_physics.html#acd904a992d44edf89932fe017f0afd44", null ],
    [ "Simulate", "class_chrum_graph_1_1_physics.html#ab70e5770c424cbc7080ecf21b142a5e3", null ],
    [ "VertexForceParam", "class_chrum_graph_1_1_physics.html#a4f39fee31caa90f66e8ab4495add3125", null ]
];